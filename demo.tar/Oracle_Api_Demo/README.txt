VM.Standard.E2.1.Micro
VM.Standard.A1.Flex